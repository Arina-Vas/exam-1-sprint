import './App.css'
import {Counter} from "./Components/Сounter.tsx";
import {useState} from "react";

const startCount = 0
const initialMaxValue = 5

function App() {

    const [count, setCount] = useState<number>(startCount);

    const [maxValue, setMaxValue] = useState<number>(initialMaxValue);

    return (
        <div className="App">
            <Counter startCount={startCount} count={count} setCount={setCount} maxValue={maxValue} setMaxValue={setMaxValue} />
        </div>
    )
}

export default App
