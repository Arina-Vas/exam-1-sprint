import {Button} from "./Button.tsx";
import {Screen} from "./Screen.tsx";

type CounterType = {
    count: number
    setCount: (num: number) => void
    maxValue: number
    setMaxValue: (num: number) => void
    startCount: number
}

export const Counter = ({count, setCount, maxValue, setMaxValue, startCount}: CounterType) => {

    const onClickIncHandler = () => {
        if (count < maxValue) setCount(++count)
    }
    const onClickResetHandler = () => {
        setCount(0)
        setMaxValue(Math.ceil(Math.random() * 10))
    }

    // const onClickHandler = (n: number) => {
    //     if (n === 0) {
    //         setCount(0)
    //         setMaxValue(Math.ceil(Math.random() * 10))
    //     } else if (count < maxValue) setCount(++count)
    // }
    return (
        <div className={'counter'}>
            <Screen count={count} maxValue={maxValue}/>
            <progress className={'progress'} max={maxValue} value={count}></progress>
            <div className={'buttons'}>
                <Button name={'inc'} disabled={count === maxValue} onclick={onClickIncHandler}/>
                <Button name={'reset'} disabled={count === startCount} onclick={onClickResetHandler}/>
            </div>
        </div>
    );
};